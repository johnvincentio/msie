
package jvbean;

public class JVRegister {
	private String email = "";
	private String password = "";
	private String firstname = "";
	private String middle = "";
	private String lastname = "";
	private String faddress = "";
	private String laddress = "";
	private String city = "";
	private String state = "";
	private String zip = "";
	private String phone = "";

	public JVRegister () {}

	public void setEmail (String str) {this.email = str;}
	public String getEmail() {return this.email;}
	public void setPassword (String str) {this.password = str;}
	public String getPassword() {return this.password;}
	public void setFirstname (String str) {this.firstname = str;}
	public String getFirstname() {return this.firstname;}
	public void setMiddle (String str) {this.middle = str;}
	public String getMiddle() {return this.middle;}
	public void setLastname (String str) {this.lastname = str;}
	public String getLastname() {return this.lastname;}
	public void setFaddress (String str) {this.faddress = str;}
	public String getFaddress() {return this.faddress;}
	public void setLaddress (String str) {this.laddress = str;}
	public String getLaddress() {return this.laddress;}
	public void setCity (String str) {this.city = str;}
	public String getCity() {return this.city;}
	public void setState (String str) {this.state = str;}
	public String getState() {return this.state;}
	public void setZip (String str) {this.zip = str;}
	public String getZip() {return this.zip;}
	public void setPhone (String str) {this.phone = str;}
	public String getPhone() {return this.phone;}
}

