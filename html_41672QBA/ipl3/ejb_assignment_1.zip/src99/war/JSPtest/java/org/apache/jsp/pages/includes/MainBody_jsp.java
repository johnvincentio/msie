package org.apache.jsp.pages.includes;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class MainBody_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  static {
    _jspx_dependants = new java.util.Vector(5);
    _jspx_dependants.add("/pages/includes/Picture.jsp");
    _jspx_dependants.add("/pages/includes/Welcome.jsp");
    _jspx_dependants.add("/pages/includes/Features.jsp");
    _jspx_dependants.add("/pages/includes/News.jsp");
    _jspx_dependants.add("/pages/includes/Comments.jsp");
  }

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n<table>\n\t<tr>\n\t\t<td valign=\"top\">\n\t\t\t");
      out.write("\r\n<table width=\"100%\">\r\n\t<tr>\r\n\t\t<td>\r\n\t\t\t<html:img page=\"/pages/images/crystals.jpg\" align=\"left\" border=\"0\"/>\r\n\r\n\t\t</td>\r\n\t</tr>\r\n\t<tr>\r\n\t\t<td>Our hard-working associates</td>\r\n\t</tr>\r\n</table>\r\n\r\n");
      out.write("\n\t\t\t<br/>\n\t\t\t");
      out.write("<style type=\"text/css\">\r\nBODY\t{ margin: 0px; }\r\nFORM    { margin: 0px; }\r\n.normal\t{ font-family: Arial, Helvetica, Sans-Serif; font-size: 8pt; text-align: justify; }\r\n.genstr { font-family: Arial, Helvetica, Sans-Serif; font-size: 8pt; font-weight: bold; }\r\n.advert { font-family: Arial, Helvetica, Sans-Serif; font-size: 7.5pt; text-align: justify; }\r\n.submit { font-family: Arial, Helvetica, Sans-Serif; font-size: 8pt; text-align: center; }\r\n.larger\t{ font-family: Arial, Helvetica, Sans-Serif; font-size: 10pt; }\r\n</style>\r\n\r\n<table  width=\"100%\">\r\n<tr>\r\n<th bgcolor=\"aqua\"><font size=\"+1\"><strong>Welcome to Thames Distributors</strong></font></th></tr>\r\n<tr>\r\n<td>\r\n<div align=\"center\">\r\n<center>\r\n<font class=\"larger\">\r\n<i>\"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...\"</i>\r\n<br />\r\n</font>\r\n</center></div>\r\n<ul>\r\n<div id=\"lipsum\" class=\"normal\">\r\n<p>\r\n<li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>\r\n<li>Integer in libero nec elit consectetuer posuere.</li>\r\n");
      out.write("<li>Nullam id nulla posuere ante venenatis porttitor.</li>\r\n<li>Vestibulum cursus pellentesque risus.</li>\r\n<li>Cras vestibulum neque a augue.</li>\r\n<li>Aenean tempus augue id enim.</li>\r\n</p>\r\n<p>\r\n<li>Proin consequat ante a libero.</li>\r\n<li>Cras ut pede in sem facilisis commodo.</li>\r\n<li>Aenean in tortor quis quam commodo tincidunt.</li>\r\n</p>\r\n<p>\r\n<li>Sed fermentum vestibulum dui.</li>\r\n<li>Fusce consectetuer wisi et nulla.</li>\r\n<li>Maecenas molestie molestie felis.</li>\r\n<li>Maecenas iaculis nibh et libero.</li>\r\n</p>\r\n<p>\r\n<li>Donec viverra justo id pede.</li>\r\n<li>Morbi gravida bibendum nunc.</li>\r\n<li>Donec adipiscing fringilla enim.</li>\r\n<li>Aliquam iaculis ultricies nulla.</li>\r\n<li>Vivamus pulvinar congue mauris.</li>\r\n</p>\r\n<p>\r\n<li>Morbi eget tortor pharetra ligula dignissim bibendum.</li>\r\n<li>Nunc ac purus eu erat egestas convallis.</li>\r\n<li>Vestibulum molestie libero non nunc adipiscing rutrum.</li>\r\n<li>Nunc in ante vel lacus suscipit vestibulum.</li>\r\n</p>\r\n</ul>\r\n\r\n</td></tr>\r\n</table>\r\n");
      out.write("\r\n");
      out.write("\n\t\t\t<br/>\n\t\t\t");
      out.write("<style type=\"text/css\">\r\nBODY\t{ margin: 0px; }\r\nFORM    { margin: 0px; }\r\n.normal\t{ font-family: Arial, Helvetica, Sans-Serif; font-size: 8pt; text-align: justify; }\r\n.genstr { font-family: Arial, Helvetica, Sans-Serif; font-size: 8pt; font-weight: bold; }\r\n.advert { font-family: Arial, Helvetica, Sans-Serif; font-size: 7.5pt; text-align: justify; }\r\n.submit { font-family: Arial, Helvetica, Sans-Serif; font-size: 8pt; text-align: center; }\r\n.larger\t{ font-family: Arial, Helvetica, Sans-Serif; font-size: 10pt; }\r\n</style>\r\n\r\n<table  width=\"100%\">\r\n<tr>\r\n<th bgcolor=\"aqua\"><font size=\"+1\"><strong>Thames Services</strong></font></th></tr>\r\n<tr>\r\n<td>\r\n\r\n<div align=\"center\">\r\n<center>\r\n<font class=\"larger\">\r\n<i>\"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...\"</i>\r\n<br />\r\n</font>\r\n</center>\r\n</div>\r\n\r\n<ul>\r\n<div id=\"lipsum\" class=\"normal\">\r\n<p>\r\n<li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>\r\n<li>Integer in libero nec elit consectetuer posuere.</li>\r\n");
      out.write("<li>Nullam id nulla posuere ante venenatis porttitor.</li>\r\n<li>Vestibulum cursus pellentesque risus.</li>\r\n<li>Cras vestibulum neque a augue.</li>\r\n<li>Aenean tempus augue id enim.</li>\r\n</p>\r\n</ul>\r\n\r\n</td></tr>\r\n</table>\r\n\r\n\r\n\r\n");
      out.write("\n\t\t\t<br/>\n\t\t</td>\n\n\t\t<td valign=\"top\">\n\t\t\t");
      out.write("<table  width=\"100%\">\r\n<tr>\r\n<th bgcolor=\"aqua\"><font size=\"+1\"><strong>News</strong></font></th></tr>\r\n<tr>\r\n<td>\r\n      <p><FONT size=2>10 June 2004</FONT></P>\r\n      <P><STRONG><EM><FONT color=#ff0000>Nullam fringilla, lectus</FONT></EM></STRONG>\r\n\t  <br><FONT color=#000000 size=2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed ut mauris. Suspendisse nec diam ut ipsum blandit blandit. Donec non augue ut felis aliquam euismod. Quisque massa turpis, ultricies sed, bibendum eget, dictum nec, quam. Nunc vel leo at tellus pulvinar sollicitudin. Nullam fringilla, lectus ut fermentum ultricies, felis lorem tincidunt nunc, ultricies volutpat lacus justo sit amet urna. Vivamus scelerisque lobortis dolor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce at pede. Maecenas ante felis, ultricies eget, dapibus ut, commodo at, pede. In viverra. \r\n\t  </FONT></P>\r\n\t  \r\n      <p><FONT size=2>09 June 2004</FONT></P>\r\n      <P><STRONG><EM><FONT color=#ff0000>Vestibulum ante ipsum primis in faucibus</FONT></EM></STRONG>\r\n");
      out.write("\t  <br><FONT color=#000000 size=2>\r\nProin placerat lacus at ante. Fusce blandit viverra nisl. Nullam lacus felis, commodo luctus, condimentum vel, pellentesque eget, nisl. Praesent eleifend odio non nisl. Nulla in mauris. Nunc magna quam, mollis non, placerat euismod, vulputate sit amet, enim. Proin nulla mi, mattis nec, eleifend sed, mollis at, diam. Donec mollis. Quisque ultricies, massa eget rutrum malesuada, orci quam aliquam mi, ac viverra tortor tellus sit amet mauris. Donec quis nibh. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras vehicula mollis risus. Donec feugiat eros nec lacus. In hac habitasse platea dictumst. Praesent vitae dui. Quisque euismod nunc ac ante. Fusce a dui in justo bibendum porttitor. Maecenas hendrerit dolor vel quam. Maecenas pretium accumsan arcu. Nunc nunc. \r\n\t  </FONT></P>\r\n\t  \r\n\t  <p><FONT size=2>01 June 2004</FONT></P>\r\n      <P><STRONG><EM><FONT color=#ff0000>Duis condimentum tempus</FONT></EM></STRONG>\r\n\t  <br><FONT color=#000000 size=2>\r\n");
      out.write("Aenean dui risus, auctor a, sagittis sit amet, fringilla vel, lectus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Morbi massa ante, feugiat quis, interdum quis, gravida id, est. Integer vel leo. Maecenas sodales interdum purus. Suspendisse aliquam blandit felis. Maecenas in nunc. Nunc quis elit quis augue pharetra vehicula. Vivamus mauris. Duis condimentum tempus arcu. Mauris egestas congue nisl. Etiam sit amet sapien non magna gravida vehicula. Duis accumsan venenatis elit. Sed porttitor est vitae augue. Aliquam gravida pulvinar augue. Mauris pretium aliquam pede. Vivamus vehicula laoreet elit. Praesent et ipsum. Pellentesque nunc.\r\n\t  </FONT></P>\r\n\r\n</td></tr></table>\r\n");
      out.write("\n\t\t\t<br/>\n\t\t\t");
      out.write("<table  width=\"100%\">\r\n<tr>\r\n<th bgcolor=\"aqua\"><font size=\"+1\"><strong>Give Your Feedback \r\n      !</STRONG></FONT></TH></TR>\r\n<tr>\r\n<td>\r\n      <P align=center>\r\n      <FONT size=2>\r\n\t  Feel free to give your feedback on this site !\r\n\t  <br>\r\n\t  If you have any idea to improve it, let me know ! \r\n      <br>Contact me at : \r\n      <br><A href=\"mailto:jv2351@hotpop.com\">jv2351@hotpop.com</A>\r\n      </FONT>\r\n\t  </P>\r\n</TD>\r\n</TR>\r\n</TABLE>");
      out.write("\n\t\t\t<br/>\n\t\t</td>\n\t</tr>\n</table>\n\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
