
select catalog,ds from catalog order by catalog;

