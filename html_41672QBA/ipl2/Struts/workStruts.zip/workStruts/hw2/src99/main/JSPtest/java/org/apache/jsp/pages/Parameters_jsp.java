package org.apache.jsp.pages;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;

public final class Parameters_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n\n");
      out.write("\n\n");
      out.write("<HR>\n");
      out.write("<H1> Parameters ");
      out.write("</H1>\n");
      out.write("<TABLE>\n");
      out.write("<TR>");
      out.write("<TD BGCOLOR=AAAAAA ALIGN=CENTER>Parameter Name");
      out.write("</TD>\n    ");
      out.write("<TD BGCOLOR=AAAAAA>Parameter Value");
      out.write("</TD>\n");
      out.write("</TR>\n\n");
 Enumeration itr1 = request.getParameterNames();
	while (itr1.hasMoreElements()) {
		String pName = (String) itr1.nextElement();
		String pValue = request.getParameter(pName); 
      out.write("\n\t\t");
      out.write("<TR>");
      out.write("<TD BGCOLOR=DDDDDD>");
      out.write(String.valueOf(pName));
      out.write("</TD>\n\t\t");
      out.write("<TD BGCOLOR=DDDDDD>");
      out.write(String.valueOf(pValue));
      out.write("</TD>\n\t\t");
      out.write("</TR>\n");
 } 
      out.write("\t\t\n");
      out.write("</TABLE>\n\n");
      out.write("<HR>\n\n");
      out.write("<H1> Attributes ");
      out.write("</H1>\n");
      out.write("<TABLE>\n");
      out.write("<TR>");
      out.write("<TD BGCOLOR=AAAAAA ALIGN=CENTER>Attribute Name");
      out.write("</TD>\n");
      out.write("</TR>\n\n");
 Enumeration itr2 = request.getAttributeNames();
	while (itr2.hasMoreElements()) {
		String pName = (String) itr2.nextElement(); 
      out.write("\n\t\t");
      out.write("<TR>");
      out.write("<TD BGCOLOR=DDDDDD>");
      out.write(String.valueOf(pName));
      out.write("</TD>\n\t\t");
      out.write("</TR>\n");
 } 
      out.write("\t\t\n");
      out.write("</TABLE>\n\n");
      out.write("<HR>\n\n");
    } catch (Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (pageContext != null) pageContext.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
